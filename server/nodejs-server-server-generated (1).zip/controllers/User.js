'use strict';

var utils = require('../utils/writer.js');
var User = require('../service/UserService');

module.exports.authenticatedSessionGET = function authenticatedSessionGET (req, res, next) {
  User.authenticatedSessionGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.authenticatedSessionUserIdDELETE = function authenticatedSessionUserIdDELETE (req, res, next, authenticatedUserId, userId) {
  User.authenticatedSessionUserIdDELETE(authenticatedUserId, userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
