'use strict';

var utils = require('../utils/writer.js');
var Keyword = require('../service/KeywordService');

module.exports.getKeywords = function getKeywords (req, res, next, authenticatedUserId) {
  Keyword.getKeywords(authenticatedUserId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
