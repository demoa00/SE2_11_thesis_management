'use strict';

var utils = require('../utils/writer.js');
var Application = require('../service/ApplicationService');

module.exports.getApplicationById = function getApplicationById (req, res, next, authenticatedUserId, thesisProposalId, studentId) {
  Application.getApplicationById(authenticatedUserId, thesisProposalId, studentId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getApplications = function getApplications (req, res, next, authenticatedUserId) {
  Application.getApplications(authenticatedUserId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.insertNewApplication = function insertNewApplication (req, res, next, body, thesisProposalId, authenticatedUserId) {
  Application.insertNewApplication(body, thesisProposalId, authenticatedUserId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateApplication = function updateApplication (req, res, next, body, thesisProposalId, studentId, authenticatedUserId) {
  Application.updateApplication(body, thesisProposalId, studentId, authenticatedUserId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
