'use strict';

var utils = require('../utils/writer.js');
var ThesisProposal = require('../service/ThesisProposalService');

module.exports.getThesisProposalById = function getThesisProposalById (req, res, next, thesisProposalId) {
  ThesisProposal.getThesisProposalById(thesisProposalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getThesisProposals = function getThesisProposals (req, res, next, authenticatedUserId, cosupervisor, codDegree, keywords, supervisor, title, thesisType, abroad, expirationDate) {
  ThesisProposal.getThesisProposals(authenticatedUserId, cosupervisor, codDegree, keywords, supervisor, title, thesisType, abroad, expirationDate)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.insertNewThesisProposal = function insertNewThesisProposal (req, res, next, body, authenticatedUserId) {
  ThesisProposal.insertNewThesisProposal(body, authenticatedUserId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
