'use strict';

var utils = require('../utils/writer.js');
var Degree = require('../service/DegreeService');

module.exports.getDegrees = function getDegrees (req, res, next, authenticatedUserId) {
  Degree.getDegrees(authenticatedUserId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
