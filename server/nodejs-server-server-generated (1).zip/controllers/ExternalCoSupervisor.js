'use strict';

var utils = require('../utils/writer.js');
var ExternalCoSupervisor = require('../service/ExternalCoSupervisorService');

module.exports.getExternalCoSupervisorById = function getExternalCoSupervisorById (req, res, next, authenticatedUserId, externalCoSupervisorId) {
  ExternalCoSupervisor.getExternalCoSupervisorById(authenticatedUserId, externalCoSupervisorId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getExternalCoSupervisors = function getExternalCoSupervisors (req, res, next, authenticatedUserId) {
  ExternalCoSupervisor.getExternalCoSupervisors(authenticatedUserId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
