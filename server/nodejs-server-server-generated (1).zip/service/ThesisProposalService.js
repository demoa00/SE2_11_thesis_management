'use strict';


/**
 *
 * thesisProposalId Integer 
 * returns thesisProposal
 **/
exports.getThesisProposalById = function(thesisProposalId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "abroad" : true,
  "requirements" : "requirements",
  "notes" : "notes",
  "keywords" : [ "keywords", "keywords" ],
  "level" : "",
  "thesisType" : "thesisType",
  "groups" : [ "groups", "groups" ],
  "description" : "description",
  "title" : "title",
  "coSupervisor" : [ {
    "coSupervisorId" : "coSupervisorId",
    "coSupervisor" : "http://example.com/aeiou",
    "surname" : "surname",
    "name" : "name"
  }, {
    "coSupervisorId" : "coSupervisorId",
    "coSupervisor" : "http://example.com/aeiou",
    "surname" : "surname",
    "name" : "name"
  } ],
  "isArchieved" : false,
  "CdS" : [ {
    "degreeId" : "degreeId",
    "titleDegree" : "titleDegree"
  }, {
    "degreeId" : "degreeId",
    "titleDegree" : "titleDegree"
  } ],
  "supervisor" : {
    "professor" : "http://example.com/aeiou",
    "surname" : "surname",
    "name" : "name",
    "professorId" : "professorId"
  },
  "thesisProposalId" : 1,
  "expirationDate" : "2000-01-23"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * authenticatedUserId String The authenticated user id corresponds to the professor that perform this request (optional)
 * cosupervisor Boolean Respresent the filter for the professor (optional)
 * codDegree String The codDegree is about the degree that the student, that perform this request, attends (optional)
 * keywords List  (optional)
 * supervisor String  (optional)
 * title String  (optional)
 * thesisType String  (optional)
 * abroad Boolean  (optional)
 * expirationDate date  (optional)
 * returns thesisProposals
 **/
exports.getThesisProposals = function(authenticatedUserId,cosupervisor,codDegree,keywords,supervisor,title,thesisType,abroad,expirationDate) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "keywords" : [ "keywords", "keywords" ],
  "surname" : "surname",
  "name" : "name",
  "self" : "http://example.com/aeiou",
  "title" : "title",
  "thesisProposalId" : 1,
  "expirationDate" : "2000-01-23"
}, {
  "keywords" : [ "keywords", "keywords" ],
  "surname" : "surname",
  "name" : "name",
  "self" : "http://example.com/aeiou",
  "title" : "title",
  "thesisProposalId" : 1,
  "expirationDate" : "2000-01-23"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * body ThesisProposal  (optional)
 * authenticatedUserId String The authenticated user id corresponds to the professor that perform this request
 * returns thesisProposal
 **/
exports.insertNewThesisProposal = function(body,authenticatedUserId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "abroad" : true,
  "requirements" : "requirements",
  "notes" : "notes",
  "keywords" : [ "keywords", "keywords" ],
  "level" : "",
  "thesisType" : "thesisType",
  "groups" : [ "groups", "groups" ],
  "description" : "description",
  "title" : "title",
  "coSupervisor" : [ {
    "coSupervisorId" : "coSupervisorId",
    "coSupervisor" : "http://example.com/aeiou",
    "surname" : "surname",
    "name" : "name"
  }, {
    "coSupervisorId" : "coSupervisorId",
    "coSupervisor" : "http://example.com/aeiou",
    "surname" : "surname",
    "name" : "name"
  } ],
  "isArchieved" : false,
  "CdS" : [ {
    "degreeId" : "degreeId",
    "titleDegree" : "titleDegree"
  }, {
    "degreeId" : "degreeId",
    "titleDegree" : "titleDegree"
  } ],
  "supervisor" : {
    "professor" : "http://example.com/aeiou",
    "surname" : "surname",
    "name" : "name",
    "professorId" : "professorId"
  },
  "thesisProposalId" : 1,
  "expirationDate" : "2000-01-23"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

