'use strict';


/**
 *
 * no response value expected for this operation
 **/
exports.authenticatedSessionGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 *
 * authenticatedUserId String The authenticated user id corresponds to the professor or student that perform this request
 * userId String The authenticated user id corresponds to the professor or student that perform this request
 * no response value expected for this operation
 **/
exports.authenticatedSessionUserIdDELETE = function(authenticatedUserId,userId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

