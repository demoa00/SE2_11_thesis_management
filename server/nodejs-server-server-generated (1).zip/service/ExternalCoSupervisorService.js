'use strict';


/**
 *
 * authenticatedUserId String The authenticated user id corresponds to the professor that perform this request
 * externalCoSupervisorId String 
 * returns externalCoSupervisor
 **/
exports.getExternalCoSupervisorById = function(authenticatedUserId,externalCoSupervisorId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "surname" : "surname",
  "name" : "name",
  "externalCoSupervisorId" : "externalCoSupervisorId",
  "self" : "http://example.com/aeiou",
  "company" : "company",
  "email" : ""
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * authenticatedUserId String The authenticated user id corresponds to the professor that perform this request
 * returns externalCoSupervisors
 **/
exports.getExternalCoSupervisors = function(authenticatedUserId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "surname" : "surname",
  "name" : "name",
  "externalCoSupervisorId" : "externalCoSupervisorId",
  "self" : "http://example.com/aeiou"
}, {
  "surname" : "surname",
  "name" : "name",
  "externalCoSupervisorId" : "externalCoSupervisorId",
  "self" : "http://example.com/aeiou"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

