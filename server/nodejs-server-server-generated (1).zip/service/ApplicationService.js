'use strict';


/**
 *
 * authenticatedUserId String The authenticated user id corresponds to the professor that perform this request
 * thesisProposalId Integer 
 * studentId Integer 
 * returns application
 **/
exports.getApplicationById = function(authenticatedUserId,thesisProposalId,studentId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "date" : "2000-01-23",
  "isReadedByProfessor" : false,
  "thesisProposalTitle" : "thesisProposalTitle",
  "isAccepted" : "",
  "message" : "message",
  "thesisProposalId" : 0,
  "applicant" : {
    "studentId" : "studentId",
    "student" : "http://example.com/aeiou",
    "surname" : "surname",
    "name" : "name"
  },
  "isReadedByStudent" : false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * authenticatedUserId String The authenticated user id corresponds to the professor that perform this request
 * returns applications
 **/
exports.getApplications = function(authenticatedUserId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "studentId" : "studentId",
  "date" : "2000-01-23",
  "thesisProposalTitle" : "thesisProposalTitle",
  "self" : "http://example.com/aeiou",
  "thesisProposalId" : 1
}, {
  "studentId" : "studentId",
  "date" : "2000-01-23",
  "thesisProposalTitle" : "thesisProposalTitle",
  "self" : "http://example.com/aeiou",
  "thesisProposalId" : 1
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * body Application  (optional)
 * thesisProposalId Integer 
 * authenticatedUserId String The authenticated user id corresponds to the student that perform this request
 * returns application
 **/
exports.insertNewApplication = function(body,thesisProposalId,authenticatedUserId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "date" : "2000-01-23",
  "isReadedByProfessor" : false,
  "thesisProposalTitle" : "thesisProposalTitle",
  "isAccepted" : "",
  "message" : "message",
  "thesisProposalId" : 0,
  "applicant" : {
    "studentId" : "studentId",
    "student" : "http://example.com/aeiou",
    "surname" : "surname",
    "name" : "name"
  },
  "isReadedByStudent" : false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * body Application  (optional)
 * thesisProposalId Integer 
 * studentId Integer 
 * authenticatedUserId String The authenticated user id corresponds to the professor that perform this request
 * returns application
 **/
exports.updateApplication = function(body,thesisProposalId,studentId,authenticatedUserId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "date" : "2000-01-23",
  "isReadedByProfessor" : false,
  "thesisProposalTitle" : "thesisProposalTitle",
  "isAccepted" : "",
  "message" : "message",
  "thesisProposalId" : 0,
  "applicant" : {
    "studentId" : "studentId",
    "student" : "http://example.com/aeiou",
    "surname" : "surname",
    "name" : "name"
  },
  "isReadedByStudent" : false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

