'use strict';


/**
 *
 * authenticatedUserId String The authenticated user id corresponds to the professor that perform this request
 * returns degrees
 **/
exports.getDegrees = function(authenticatedUserId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "degreeId" : "degreeId",
  "titleDegree" : "titleDegree"
}, {
  "degreeId" : "degreeId",
  "titleDegree" : "titleDegree"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

